<?php return array (
  'album-component' => 'App\\Http\\Livewire\\AlbumComponent',
  'bank-component' => 'App\\Http\\Livewire\\BankComponent',
  'bank-table' => 'App\\Http\\Livewire\\BankTable',
  'freelancer-component' => 'App\\Http\\Livewire\\FreelancerComponent',
  'freelancer-table' => 'App\\Http\\Livewire\\FreelancerTable',
  'leads-component' => 'App\\Http\\Livewire\\LeadsComponent',
  'leads-table' => 'App\\Http\\Livewire\\LeadsTable',
  'storedesc-component' => 'App\\Http\\Livewire\\StoredescComponent',
  'user-component' => 'App\\Http\\Livewire\\UserComponent',
  'user-table' => 'App\\Http\\Livewire\\UserTable',
);