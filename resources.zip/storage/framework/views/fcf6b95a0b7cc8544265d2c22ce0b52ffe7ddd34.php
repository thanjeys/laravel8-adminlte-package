<div>

    <div class="card card-success">
        <div class="card-header">
            <h3 class="card-title">Write Description</h3>
        </div>

        <div class="card-body">
            <?php if($message): ?>
            <br><span  class="text-success" style="font-size: 11.5px;"><?php echo e($message); ?></span>
            <?php endif; ?>

            <form wire:submit.prevent="storeDesc">
                <textarea wire:model="desc" name="desc" class="form-control" id="desc" cols="20" rows="5"></textarea>
                <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" style="font-size: 11.5px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br><button style="width:100px; margin:0 auto" type="submit" class="btn btn-block btn-primary">Submit</button>
             </form>
        </div>
    </div> <!-- /.card -->
</div>
<?php /**PATH D:\Laravel_Apps\LEARNING\Works\AishwaryaAlbums\resources\views\livewire\storedesc-component.blade.php ENDPATH**/ ?>