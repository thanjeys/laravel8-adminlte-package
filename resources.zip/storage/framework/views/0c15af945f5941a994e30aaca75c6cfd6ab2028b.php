<div>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>User <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#createModal">New User</button></h1>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php if(session('successMsg')): ?>
                    <div class="alert alert-success text-center"><?php echo e(session('successMsg')); ?></div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-table', [])->html();
} elseif ($_instance->childHasBeenRendered('l2917958328-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2917958328-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2917958328-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2917958328-0');
} else {
    $response = \Livewire\Livewire::mount('user-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2917958328-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php echo $__env->make('livewire.users.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.users.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.users.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startPush('scripts'); ?>
    <script>
        window.livewire.on('closeModal', () => {

        $('#updateModal').modal('hide');
        $('#deleteModal').modal('hide');
        $('#createModal').modal('hide');
    })
    window.livewire.on('showUpdateModal', () => {
        $('#updateModal').modal('show');
    })
    window.livewire.on('showDeleteModal', () => {
        $('#deleteModal').modal('show');
    })

    </script>
    <?php $__env->stopPush(); ?>

</div>
<?php /**PATH D:\Laravel_Apps\LEARNING\Works\LeadMgmt\resources\views/livewire/user-component.blade.php ENDPATH**/ ?>