<!-- Create Modal -->
<div wire:ignore.self class="modal fade" id="updateModal" tabindex="-1" data-backdrop="static" data-keyboard="false" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update User</h5>
                <button type="button" wire:click.prevent="cancel()" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <?php if($errors->any()): ?>
                    <ul class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>

                <form wire:submit.prevent="update">


                    <div class="form-group row">
                        <label for="name" class="col-4">Name</label>
                        <div class="col-8">
                            <input type="text" id="name" class="form-control" wire:model="name">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email" class="col-4">Email</label>
                        <div class="col-8">
                            <input type="text" id="email" class="form-control" wire:model="email">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="password" class="col-4">Password</label>
                        <div class="col-8">
                            <input type="text" id="password" class="form-control" wire:model="password">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="role" class="col-4">Role</label>
                        <div class="col-8">
                            <select wire:change="newroleselection()" id="role" class="form-control" wire:model="is_admin">
                                <option  value="">Select Role</option>
                                <option <?php echo e(($is_admin == 0) ? 'selected' : ''); ?> value="0">Telecaller</option>
                                <option <?php echo e(($is_admin == 2) ? 'selected' : ''); ?>  value="2">Backend</option>
                                <option <?php echo e(($is_admin == 1) ? 'selected' : ''); ?> value="1">Administrator</option>
                            </select>
                        </div>
                    </div>

                    <?php if($showBanks && $user_edit_id): ?>
                        <div class="form-group row">
                            <label for="role" class="col-4">Assign Banks</label>
                            <div class="col-8">
                                <div class="row">
                                    <?php $__currentLoopData = $banksList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col">
                                    <input wire:model="banks.<?php echo e($loop->index); ?>" type="checkbox" id="bank-<?php echo e($bank->id); ?>" value="<?php echo e($bank->id); ?>"><label style="font-weight:normal" for="bank-<?php echo e($bank->id); ?>"><?php echo e($bank->bank_name); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                    <?php endif; ?>




                    


                    <div class="form-group row justify-content-center">
                        <div class="col-4"></div>
                        <div class="col-8">
                            <button type="submit" class="btn btn-sm btn-primary">Save User</button>
                            <button type="button" wire:click.prevent="cancel()" data-dismiss="modal" aria-label="Close" class="btn btn-sm btn-danger">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel_Apps\LEARNING\Works\LeadMgmt\resources\views/livewire/users/update.blade.php ENDPATH**/ ?>