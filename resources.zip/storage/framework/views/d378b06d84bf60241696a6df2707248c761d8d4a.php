<div>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Albums <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#createModal">Add
                            New</button></h1>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php if(session('message')): ?>
                    <div class="alert alert-success text-center"><?php echo e(session('message')); ?></div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"></h3>

                            <div class="card-tools">
                                <div class="input-group input-group-sm" style="width: 250px;">
                                    <input type="search" class="form-control w-25" placeholder="search" wire:model="searchTerm" class="form-control float-right">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-default">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <table class="table table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Title</th>
                                        <th>Created On</th>
                                        <th>Album</th>
                                        <th>Images</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($album->title); ?></td>
                                        <td> <?php echo e($album->created_at->format('d-m-Y')); ?> </td>
                                        <td>
                                            <button class="btn btn-sm btn-primary"
                                                wire:click="edit(<?php echo e($album->id); ?>)">Edit</button>
                                            <button class="btn btn-sm btn-danger" data-toggle="modal"
                                                data-target="#deleteModal"
                                                wire:click="deleteConfirmation(<?php echo e($album->id); ?>, 'deletealbum')">Delete</button>
                                                <a target="_blank" class="btn btn-sm btn-success"
                                                href="<?php echo e(route('show.album', $album->code)); ?>">View Public</a>
                                        </td>
                                        <td>
                                            <a class="btn btn-sm btn-secondary"
                                                href="<?php echo e(route('add.image', $album->id)); ?>">Add</a>
                                            <a class="btn btn-sm btn-primary"
                                                href="<?php echo e(route('edit.image', $album->id)); ?>">View & Edit</a>

                                            <button class="btn btn-sm btn-danger" data-toggle="modal"
                                                data-target="#deleteModal"
                                                wire:click="deleteConfirmation(<?php echo e($album->id); ?>, 'deletealbumimages')">Delete All Images</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" style="text-align: center;"><small>No album Found</small></td>
                                    </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('livewire.albums.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.albums.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.albums.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startPush('scripts'); ?>
    <script>
        window.livewire.on('closeModal', () => {
        $('#createModal').modal('hide');
        $('#updateModal').modal('hide');
        $('#deleteModal').modal('hide');
    })
    window.livewire.on('showUpdateModal', () => {
        $('#updateModal').modal('show');
    })

    </script>
    <?php $__env->stopPush(); ?>

</div>
<?php /**PATH D:\Laravel_Apps\LEARNING\Works\AishwaryaAlbums\resources\views/livewire/album-component.blade.php ENDPATH**/ ?>