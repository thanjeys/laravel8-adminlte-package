<li class="nav-item">
    <a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e(request()->routeIs('home') ? " active" : null); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Home</p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('leads')); ?>" class="nav-link <?php echo e(request()->routeIs('leads') ? " active" : null); ?>">
        <i class="nav-icon fas fa-columns"></i>
        <p>Leads</p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('sanctioned.report')); ?>" class="nav-link <?php echo e(request()->routeIs('sanctioned.report') ? " active" : null); ?>">
        <i class="nav-icon fas fa-columns"></i>
        <p>Sanctioned Loan</p>
    </a>
</li>



<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>



<li class="nav-item">
    <a href="<?php echo e(route('freelancers')); ?>" class="nav-link <?php echo e(request()->routeIs('freelancers') ? " active" : null); ?>">
        <i class="nav-icon fas fa-columns"></i>
        <p>Freelancers</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('banks')); ?>" class="nav-link <?php echo e(request()->routeIs('banks') ? " active" : null); ?>">
        <i class="nav-icon fas fa-columns"></i>
        <p>Banks</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('users')); ?>" class="nav-link <?php echo e(request()->routeIs('users') ? " active" : null); ?>">
        <i class="nav-icon fas fa-table"></i>
        <p>Users</p>
    </a>
</li>
<?php endif; ?>

<li class="nav-item">
    <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="nav-link">
        <i class="nav-icon fas fa-columns"></i>
        <p>Logout</p>
    </a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
    </form>
</li>
<?php /**PATH D:\Laravel_Apps\LEARNING\Works\LeadMgmt\resources\views/layouts/menu.blade.php ENDPATH**/ ?>