<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.4.0/min/dropzone.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <?php echo e($album->title); ?> Album
                    <a class="btn btn-sm btn-outline-success" href="<?php echo e(route('myalbums')); ?> ">Back to Albums</a></h1>
            </div>
        </div>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <?php if(session('message')): ?>
                <div class="alert alert-success text-center"><?php echo e(session('message')); ?></div>
                <?php endif; ?>

                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Upload Pictures</h3>
                    </div>

                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('store.image', $album->id)); ?>" enctype="multipart/form-data" class="dropzone" id="dropzone">
                         <?php echo csrf_field(); ?>
                         </form>
                    </div>
                </div> <!-- /.card -->

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('storedesc-component', ['albumId'=> $album->id])->html();
} elseif ($_instance->childHasBeenRendered('ePhqNeV')) {
    $componentId = $_instance->getRenderedChildComponentId('ePhqNeV');
    $componentTag = $_instance->getRenderedChildComponentTagName('ePhqNeV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ePhqNeV');
} else {
    $response = \Livewire\Livewire::mount('storedesc-component', ['albumId'=> $album->id]);
    $html = $response->html();
    $_instance->logRenderedChild('ePhqNeV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.4.0/dropzone.js"></script>

<script type="text/javascript">
    Dropzone.options.dropzone =
     {
        maxFilesize: 12,
        renameFile: function(file) {
            var dt = new Date();
            var time = dt.getTime();
           return time+file.name;
        },
        acceptedFiles: ".jpeg,.jpg,.png,.gif",
        timeout: 5000,
        addRemoveLinks: true,
        removedfile: function(file)
        {
            var name = file.upload.filename;
            $.ajax({
                headers: {
                            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                        },
                type: 'POST',
                url: "<?php echo e(route('destroy.image', $album->id)); ?>",
                data: {filename: name},
                success: function (data){
                    console.log("File deleted successfully!!");
                },
                error: function(e) {
                    console.log(e);
                }});
                var fileRef;
                return (fileRef = file.previewElement) != null ?
                fileRef.parentNode.removeChild(file.previewElement) : void 0;
        },
        success: function(file, response)
        {
            console.log(response);
        },
        error: function(file, response)
        {
           return false;
        }
};
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_Apps\LEARNING\Works\AishwaryaAlbums\resources\views\addpicture.blade.php ENDPATH**/ ?>