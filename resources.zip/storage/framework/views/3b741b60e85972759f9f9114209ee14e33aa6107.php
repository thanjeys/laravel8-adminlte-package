<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Sanctioned Loan Month</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

        <?php $__currentLoopData = $all_report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-6">
                <div class="small-box <?php echo e($loop->even ? 'bg-info' : 'bg-warning'); ?>">
                    <div class="inner">
                        <h3><?php echo e($report['sanctioned_amount']); ?></h3>
                        <p><?php echo e($report['bank_name']); ?> </p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                    <a href="#" class="small-box-footer">Cycle Date : <?php echo e($report['monthly_cycle']); ?> </a>
                    
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_Apps\LEARNING\Works\LeadMgmt\resources\views/sanctioned-report.blade.php ENDPATH**/ ?>