<!-- need to remove -->
<li class="nav-item">
    <a href="<?php echo e(route('myalbums')); ?>" class="nav-link active">
        <i class="nav-icon fas fa-home"></i>
        <p>Albums</p>
    </a>
</li>
<?php /**PATH D:\Laravel_Apps\LEARNING\Works\AishwaryaAlbums\resources\views\layouts\menu.blade.php ENDPATH**/ ?>