<div>
    <div class="card">
        

        <div class="card-body" style="background:#efefef">

            <?php if(session('updatemsg')): ?>
                <br><span  class="text-success" style="font-size: 11.5px;"><?php echo e(session('updatemsg')); ?></span>
            <?php endif; ?>
            <form wire:submit.prevent="updateDesc">
                <textarea wire:model="desc" name="desc" class="form-control" id="desc" cols="20" rows="5"></textarea>
                <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" style="font-size: 11.5px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br><button type="submit" class="btn btn-primary">Update</button>
                <a class="btn btn-outline-danger" href="<?php echo e(route('remove.picture', $picture_id)); ?>" onclick="return confirm('Are you sure you want to delete this Picture')">Remove</a>
             </form>

        </div>
    </div> <!-- /.card -->
</div>
<?php /**PATH D:\Laravel_Apps\LEARNING\Works\AishwaryaAlbums\resources\views\livewire\edit-picture-component.blade.php ENDPATH**/ ?>