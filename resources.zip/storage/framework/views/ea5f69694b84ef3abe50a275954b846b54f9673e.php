<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Aishwaryavideos - <?php echo e($album->title); ?> </title>
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('site/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: "Open Sans", sans-serif;
            font-size: 14px;
            font-weight: 400;
            color: #666;
        }
        .welcome-text {
            color: #850c6e;
            font-family:"Open Sans", sans-serif;
            font-size: 26px;
            font-weight: 300;
            padding: 35px 0 40px 0;
            text-align: center;
        }
        header {
            border-bottom: 3px solid #d9dcdd;
            padding-bottom: 20px;
        }
        main {
            margin-top: 30px;
        }
        footer {
            border-top: 3px solid #d9dcdd;
            padding-top: 30px;
            margin-top: 30px;
        }
        .desc {
            padding: 30px;
            background: #fafafa;
            border: dashed 2px #850c6e;
            margin: 30px;
            color: #000;
        }
    </style>



</head>

<body>
    <header class="container">
        <div class="row justify-content-between align-items-center">
            <div class="col-lg-2">
                <a href="https://aishwaryavideos.com/">
                    <img src="<?php echo e(asset('site/avp_logo-4.jpg')); ?>">
                </a>
            </div>
            <div class="col-lg-7 text-center welcome-text">
                <?php echo e($album->title); ?>

            </div>
            <div class="col-lg-3 d-flex justify-content-end align-items-center">
                Contact: +9198422 23291<br>
                E-mail: info@aishwaryavideos.com<br>
                4/A1, N.G.N Street, New Siddhapudur, Coimbatore – 641 044.<br></div>
            </div>
        </div>
    </header>

    <main class="container">

        <?php $__empty_1 = true; $__currentLoopData = $album->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-12">
            <?php if($picture->type == "image"): ?>
                <a href="<?php echo e(asset("albums/$picture->album_id/$picture->image_name")); ?>" target="_blank"><img
                        class="img-fluid" src='<?php echo e(asset("albums/$picture->album_id/$picture->image_name")); ?>'
                        alt="<?php echo e($picture->image_name); ?> "></a>
                <br><br>
            <?php else: ?>
                <div class="desc">
                    <?php echo e($picture->description); ?>

                </div>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h2>No Pictures and Text Found </h2>
        <?php endif; ?>
    </main>

    <footer class="blog-footer text-center container">
        <p>© <?php echo e(date('Y')); ?> Aishwarya Photos & Videos. All Rights Reserved.
            <a href="https://aishwaryavideos.com/">Aishwarya Photos</a>
        </p>
        <p>
            <a href="#">Back to top</a>
        </p>
    </footer>

</body>
</html>
<?php /**PATH D:\Laravel_Apps\LEARNING\Works\AishwaryaAlbums\resources\views\showalbum.blade.php ENDPATH**/ ?>