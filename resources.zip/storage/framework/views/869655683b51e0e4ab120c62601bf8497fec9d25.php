<div wire:loading class="mt-2">
    <div class="loader ease-linear rounded-full border-2 border-t-2 border-slate-200 h-6 w-6"></div>
</div>
<?php /**PATH D:\Laravel_Apps\LEARNING\Works\LeadMgmt\resources\views/vendor/livewire-powergrid/components/frameworks/tailwind/header/loading.blade.php ENDPATH**/ ?>