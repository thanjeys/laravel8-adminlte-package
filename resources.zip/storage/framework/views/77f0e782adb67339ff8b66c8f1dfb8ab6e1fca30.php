<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Bank Category</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <iframe src="http://lzapp.in/app/BankCategory" width="100%" height="800px" frameborder="0"></iframe>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_Apps\LEARNING\Works\LeadMgmt\resources\views/bankcategory.blade.php ENDPATH**/ ?>