<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <?php echo e($album->title); ?> Edit Album
                    <a class="btn btn-sm btn-outline-success" href="<?php echo e(route('myalbums')); ?> ">Back to Albums</a></h1>
            </div>
        </div>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
              <?php if(session('message')): ?>
                <p class="alert alert-success"> <?php echo e(session('message')); ?> </p>
              <?php endif; ?>
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($picture->type== "image"): ?>
                            <div class="col-md-3">
                                <div class="card">
                                    <div class="card-body">
                                        <img class="img-fluid" src="<?php echo e(asset('albums/'.$album->id.'/'.$picture->image_name)); ?>" alt="<?php echo e($picture->image_name); ?>"> <br> <br>
                                        <a class="btn btn-outline-danger" href="<?php echo e(route('remove.picture', $picture->id)); ?>" onclick="return confirm('Are you sure you want to delete this Picture')">Remove</a>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="col-md-12">
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('edit-picture-component', ['picture_id' => $picture->id])->html();
} elseif ($_instance->childHasBeenRendered('pyE83K1')) {
    $componentId = $_instance->getRenderedChildComponentId('pyE83K1');
    $componentTag = $_instance->getRenderedChildComponentTagName('pyE83K1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pyE83K1');
} else {
    $response = \Livewire\Livewire::mount('edit-picture-component', ['picture_id' => $picture->id]);
    $html = $response->html();
    $_instance->logRenderedChild('pyE83K1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h3>No Picures found</h3>
                    <?php endif; ?>
                </div>

                

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_Apps\LEARNING\Works\AishwaryaAlbums\resources\views\editpicture.blade.php ENDPATH**/ ?>